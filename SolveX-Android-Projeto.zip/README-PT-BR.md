# SolveX para Android — projeto inicial

Este projeto cria um aplicativo Android simples que abre https://solvexweb.com/ em uma WebView.

## O que está incluído
- Aplicativo Android com nome SolveX.
- WebView com JavaScript e armazenamento local habilitados para permitir o funcionamento do site.
- Links externos abertos no navegador do aparelho.
- Workflow do GitHub Actions para compilar e disponibilizar o arquivo `.aab` como artefato.

## Como compilar usando apenas o celular
1. Baixe e descompacte este ZIP, se necessário.
2. Entre em https://github.com/ pelo navegador e crie uma conta ou entre na sua conta.
3. Crie um repositório novo chamado `solvex-android`.
4. Envie os arquivos e pastas deste projeto para o repositório, mantendo a estrutura.
5. Abra a aba **Actions** do repositório.
6. Se solicitado, habilite GitHub Actions.
7. Execute **Build SolveX AAB** em **Run workflow** (ou faça um commit na branch `main` para iniciar automaticamente).
8. Quando terminar, abra a execução concluída e baixe o artefato `solvex-release-aab`.

## Importante sobre a Google Play
Este primeiro projeto gera o pacote AAB de compilação, mas ainda não configura uma chave privada de upload. Para publicar na Play Store, será necessário configurar uma chave de assinatura de upload e assinar o AAB. Guarde essa chave e sua senha em local seguro; não publique esses dados no repositório.

Também será necessário verificar os requisitos atuais da Play Console, preencher a ficha do app, política de privacidade e concluir os testes exigidos pela conta.

## Limitações desta versão inicial
- É uma primeira versão WebView; ainda não foi testada em todos os fluxos do SolveX.
- Upload de arquivos, notificações push, permissões especiais e alguns fluxos de pagamento podem exigir implementação adicional.
- O aplicativo depende de internet e do site estar disponível.
- Antes de publicar, teste login, cadastro, postagem, pagamentos, links externos e navegação no botão voltar.
